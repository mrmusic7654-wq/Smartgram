package com.ssolutions.smartgram.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.ssolutions.smartgram.models.Message;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    
    public MessageDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }
    
    public void open() {
        database = dbHelper.getWritableDatabase();
    }
    
    public void close() {
        dbHelper.close();
    }
    
    public long addMessage(Message message) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY_TELEGRAM_MESSAGE_ID, message.getId());
        values.put(DatabaseHelper.KEY_CHAT_ID, message.getSenderId());
        values.put(DatabaseHelper.KEY_MESSAGE_TEXT, message.getText());
        values.put(DatabaseHelper.KEY_SENDER_ID, message.getSenderId());
        values.put(DatabaseHelper.KEY_MESSAGE_TYPE, message.getMessageType());
        values.put(DatabaseHelper.KEY_IS_SENT, message.isSent() ? 1 : 0);
        values.put(DatabaseHelper.KEY_TIMESTAMP, message.getTimestamp());
        
        return database.insert(DatabaseHelper.TABLE_MESSAGES, null, values);
    }
    
    public List<Message> getMessagesForChat(String chatId) {
        List<Message> messages = new ArrayList<>();
        
        Cursor cursor = database.query(DatabaseHelper.TABLE_MESSAGES,
                null,
                DatabaseHelper.KEY_CHAT_ID + " = ?",
                new String[]{chatId},
                null, null, DatabaseHelper.KEY_CREATED_AT + " ASC");
        
        if (cursor.moveToFirst()) {
            do {
                Message message = new Message();
                message.setId(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_TELEGRAM_MESSAGE_ID)));
                message.setSenderId(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_SENDER_ID)));
                message.setText(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_MESSAGE_TEXT)));
                message.setTimestamp(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_TIMESTAMP)));
                message.setSent(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_IS_SENT)) == 1);
                message.setMessageType(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_MESSAGE_TYPE)));
                
                messages.add(message);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        return messages;
    }
    
    public void deleteMessage(String messageId) {
        database.delete(DatabaseHelper.TABLE_MESSAGES,
                DatabaseHelper.KEY_TELEGRAM_MESSAGE_ID + " = ?",
                new String[]{messageId});
    }
}