package com.ssolutions.smartgram.models;

public class Chat {
    private String id;
    private String name;
    private String lastMessage;
    private String timestamp;
    private String avatar;
    private boolean isGroup;
    private int unreadCount;
    
    // Constructors
    public Chat() {}
    
    public Chat(String id, String name, String lastMessage, String timestamp, boolean isGroup) {
        this.id = id;
        this.name = name;
        this.lastMessage = lastMessage;
        this.timestamp = timestamp;
        this.isGroup = isGroup;
        this.unreadCount = 0;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getLastMessage() { return lastMessage; }
    public void setLastMessage(String lastMessage) { this.lastMessage = lastMessage; }
    
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    
    public String getAvatar() { return avatar; }
    public void setAvatar(String avatar) { this.avatar = avatar; }
    
    public boolean isGroup() { return isGroup; }
    public void setGroup(boolean group) { isGroup = group; }
    
    public int getUnreadCount() { return unreadCount; }
    public void setUnreadCount(int unreadCount) { this.unreadCount = unreadCount; }
}