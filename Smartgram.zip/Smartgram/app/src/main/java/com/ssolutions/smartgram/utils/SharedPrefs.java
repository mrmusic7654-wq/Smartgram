package com.ssolutions.smartgram.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefs {
    private static final String PREFS_NAME = "smartgram_prefs";
    private static SharedPreferences sharedPreferences;
    
    // Key names
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_BOT_TOKEN = "bot_token";
    private static final String KEY_TELEGRAM_USER_ID = "telegram_user_id";
    private static final String KEY_PHONE_NUMBER = "phone_number";
    private static final String KEY_LAST_SYNC = "last_sync";
    private static final String KEY_AUTO_DOWNLOAD = "auto_download";
    
    public static void init(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    // User ID
    public static void setUserId(String userId) {
        sharedPreferences.edit().putString(KEY_USER_ID, userId).apply();
    }
    
    public static String getUserId() {
        return sharedPreferences.getString(KEY_USER_ID, "");
    }
    
    // User Name
    public static void setUserName(String userName) {
        sharedPreferences.edit().putString(KEY_USER_NAME, userName).apply();
    }
    
    public static String getUserName() {
        return sharedPreferences.getString(KEY_USER_NAME, "User");
    }
    
    // Login Status
    public static void setLoggedIn(boolean isLoggedIn) {
        sharedPreferences.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).apply();
    }
    
    public static boolean isLoggedIn() {
        return sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);
    }
    
    // Bot Token
    public static void setBotToken(String botToken) {
        sharedPreferences.edit().putString(KEY_BOT_TOKEN, botToken).apply();
    }
    
    public static String getBotToken() {
        return sharedPreferences.getString(KEY_BOT_TOKEN, "");
    }
    
    // Telegram User ID
    public static void setTelegramUserId(String userId) {
        sharedPreferences.edit().putString(KEY_TELEGRAM_USER_ID, userId).apply();
    }
    
    public static String getTelegramUserId() {
        return sharedPreferences.getString(KEY_TELEGRAM_USER_ID, "");
    }
    
    // Phone Number
    public static void setPhoneNumber(String phoneNumber) {
        sharedPreferences.edit().putString(KEY_PHONE_NUMBER, phoneNumber).apply();
    }
    
    public static String getPhoneNumber() {
        return sharedPreferences.getString(KEY_PHONE_NUMBER, "");
    }
    
    // Last Sync
    public static void setLastSync(long timestamp) {
        sharedPreferences.edit().putLong(KEY_LAST_SYNC, timestamp).apply();
    }
    
    public static long getLastSync() {
        return sharedPreferences.getLong(KEY_LAST_SYNC, 0);
    }
    
    // Auto Download
    public static void setAutoDownload(boolean autoDownload) {
        sharedPreferences.edit().putBoolean(KEY_AUTO_DOWNLOAD, autoDownload).apply();
    }
    
    public static boolean getAutoDownload() {
        return sharedPreferences.getBoolean(KEY_AUTO_DOWNLOAD, true);
    }
    
    // Clear all preferences (logout)
    public static void clearAll() {
        sharedPreferences.edit().clear().apply();
    }
}