package com.ssolutions.smartgram.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class ContactDAO {
    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;
    
    public ContactDAO(Context context) {
        dbHelper = new DatabaseHelper(context);
    }
    
    public void open() {
        database = dbHelper.getWritableDatabase();
    }
    
    public void close() {
        dbHelper.close();
    }
    
    public long addContact(String name, String phoneNumber, String telegramUserId) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY_CONTACT_NAME, name);
        values.put(DatabaseHelper.KEY_PHONE_NUMBER, phoneNumber);
        values.put(DatabaseHelper.KEY_TELEGRAM_USER_ID, telegramUserId);
        
        return database.insert(DatabaseHelper.TABLE_CONTACTS, null, values);
    }
    
    public List<String[]> getAllContacts() {
        List<String[]> contacts = new ArrayList<>();
        
        Cursor cursor = database.query(DatabaseHelper.TABLE_CONTACTS,
                new String[]{
                    DatabaseHelper.KEY_CONTACT_NAME,
                    DatabaseHelper.KEY_PHONE_NUMBER,
                    DatabaseHelper.KEY_TELEGRAM_USER_ID
                },
                null, null, null, null, DatabaseHelper.KEY_CONTACT_NAME + " ASC");
        
        if (cursor.moveToFirst()) {
            do {
                String[] contact = new String[3];
                contact[0] = cursor.getString(0); // name
                contact[1] = cursor.getString(1); // phone
                contact[2] = cursor.getString(2); // telegram id
                contacts.add(contact);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        return contacts;
    }
    
    public String getContactNameByTelegramId(String telegramId) {
        Cursor cursor = database.query(DatabaseHelper.TABLE_CONTACTS,
                new String[]{DatabaseHelper.KEY_CONTACT_NAME},
                DatabaseHelper.KEY_TELEGRAM_USER_ID + " = ?",
                new String[]{telegramId},
                null, null, null);
        
        String name = null;
        if (cursor.moveToFirst()) {
            name = cursor.getString(0);
        }
        
        cursor.close();
        return name;
    }
    
    public boolean contactExists(String telegramUserId) {
        Cursor cursor = database.query(DatabaseHelper.TABLE_CONTACTS,
                new String[]{DatabaseHelper.KEY_ID},
                DatabaseHelper.KEY_TELEGRAM_USER_ID + " = ?",
                new String[]{telegramUserId},
                null, null, null);
        
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
    
    public int deleteContact(String telegramUserId) {
        return database.delete(DatabaseHelper.TABLE_CONTACTS,
                DatabaseHelper.KEY_TELEGRAM_USER_ID + " = ?",
                new String[]{telegramUserId});
    }
    
    public int updateContact(String oldTelegramId, String newName, String newPhone) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.KEY_CONTACT_NAME, newName);
        values.put(DatabaseHelper.KEY_PHONE_NUMBER, newPhone);
        
        return database.update(DatabaseHelper.TABLE_CONTACTS,
                values,
                DatabaseHelper.KEY_TELEGRAM_USER_ID + " = ?",
                new String[]{oldTelegramId});
    }
}