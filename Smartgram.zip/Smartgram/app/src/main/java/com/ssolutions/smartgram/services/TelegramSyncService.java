package com.ssolutions.smartgram.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;
import com.ssolutions.smartgram.utils.SharedPrefs;
import com.ssolutions.smartgram.network.TelegramAPI;
import com.ssolutions.smartgram.utils.NetworkManager;

public class TelegramSyncService extends Service {
    
    private TelegramAPI telegramAPI;
    private NetworkManager networkManager;
    private boolean isRunning = false;
    
    @Override
    public void onCreate() {
        super.onCreate();
        telegramAPI = new TelegramAPI(this);
        networkManager = new NetworkManager(this);
        
        Toast.makeText(this, "Telegram Sync Service Started", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!isRunning && SharedPrefs.isLoggedIn()) {
            isRunning = true;
            startSyncService();
        }
        return START_STICKY;
    }
    
    private void startSyncService() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (isRunning) {
                    try {
                        if (networkManager.isNetworkAvailable()) {
                            // Sync messages every 30 seconds
                            syncMessages();
                        }
                        
                        // Wait 30 seconds before next sync
                        Thread.sleep(30000);
                        
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        break;
                    }
                }
            }
        }).start();
    }
    
    private void syncMessages() {
        // This will be implemented in Phase 3 for real message syncing
        // For Phase 2, just check bot status
        if (SharedPrefs.isLoggedIn()) {
            // Simulate sync activity
            android.util.Log.d("TelegramSync", "Checking for new messages...");
        }
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        Toast.makeText(this, "Telegram Sync Service Stopped", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}