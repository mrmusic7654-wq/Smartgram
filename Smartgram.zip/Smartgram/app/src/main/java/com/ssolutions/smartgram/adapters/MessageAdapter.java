package com.ssolutions.smartgram.adapters;

import com.ssolutions.smartgram.models.Message;

// Simple adapter - we'll implement RecyclerView later when dependencies work
public class MessageAdapter {
    // This is a placeholder for now
    // We'll implement the actual adapter when we have RecyclerView working
}