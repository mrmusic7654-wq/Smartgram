package com.ssolutions.smartgram.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.ssolutions.smartgram.database.DatabaseHelper;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ContactsActivity extends Activity {
    
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;
    private LinearLayout contactsLayout;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize database
        dbHelper = new DatabaseHelper(this);
        database = dbHelper.getReadableDatabase();
        
        createContactsUI();
        loadContacts();
    }
    
    private void createContactsUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.WHITE);
        
        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(Color.parseColor("#0088CC"));
        header.setPadding(20, 20, 20, 20);
        
        TextView headerText = new TextView(this);
        headerText.setText("Contacts");
        headerText.setTextSize(18);
        headerText.setTextColor(Color.WHITE);
        
        header.addView(headerText);
        
        // Contacts container with ScrollView
        LinearLayout scrollContent = new LinearLayout(this);
        scrollContent.setOrientation(LinearLayout.VERTICAL);
        scrollContent.setPadding(20, 20, 20, 20);
        
        contactsLayout = new LinearLayout(this);
        contactsLayout.setOrientation(LinearLayout.VERTICAL);
        
        // Add demo contacts button
        Button addDemoButton = new Button(this);
        addDemoButton.setText("Add Demo Contacts");
        addDemoButton.setBackgroundColor(Color.parseColor("#4CAF50"));
        addDemoButton.setTextColor(Color.WHITE);
        addDemoButton.setPadding(20, 15, 20, 15);
        addDemoButton.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        addDemoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDemoContacts();
            }
        });
        
        scrollContent.addView(addDemoButton);
        scrollContent.addView(contactsLayout);
        
        // Add all views to main layout
        mainLayout.addView(header);
        mainLayout.addView(scrollContent);
        
        setContentView(mainLayout);
    }
    
    private void loadContacts() {
        contactsLayout.removeAllViews();
        
        Cursor cursor = database.query(
            DatabaseHelper.TABLE_CONTACTS,
            null, null, null, null, null, 
            DatabaseHelper.KEY_CONTACT_NAME + " ASC"
        );
        
        if (cursor.getCount() == 0) {
            // Show empty state
            TextView emptyText = new TextView(this);
            emptyText.setText("No contacts found.\nAdd demo contacts to get started.");
            emptyText.setTextSize(16);
            emptyText.setTextColor(Color.GRAY);
            emptyText.setPadding(0, 50, 0, 50);
            emptyText.setGravity(android.view.Gravity.CENTER);
            contactsLayout.addView(emptyText);
        } else {
            // Display contacts
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CONTACT_NAME));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_PHONE_NUMBER));
                String telegramId = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_TELEGRAM_USER_ID));
                
                addContactItem(name, phone, telegramId);
            }
        }
        
        cursor.close();
    }
    
    private void addContactItem(String name, String phone, String telegramId) {
        LinearLayout contactItem = new LinearLayout(this);
        contactItem.setOrientation(LinearLayout.VERTICAL);
        contactItem.setBackgroundColor(Color.parseColor("#F8F8F8"));
        contactItem.setPadding(20, 15, 20, 15);
        contactItem.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        // Set margin between items
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) contactItem.getLayoutParams();
        params.setMargins(0, 0, 0, 10);
        contactItem.setLayoutParams(params);
        
        // Contact name
        TextView nameText = new TextView(this);
        nameText.setText(name);
        nameText.setTextSize(18);
        nameText.setTextColor(Color.BLACK);
        nameText.setPadding(0, 0, 0, 5);
        
        // Contact phone
        TextView phoneText = new TextView(this);
        phoneText.setText("📱 " + phone);
        phoneText.setTextSize(14);
        phoneText.setTextColor(Color.DKGRAY);
        phoneText.setPadding(0, 0, 0, 5);
        
        // Telegram ID
        TextView telegramText = new TextView(this);
        telegramText.setText("✈️ Telegram ID: " + telegramId);
        telegramText.setTextSize(12);
        telegramText.setTextColor(Color.GRAY);
        
        // Action buttons
        LinearLayout buttonLayout = new LinearLayout(this);
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setPadding(0, 10, 0, 0);
        
        Button messageButton = new Button(this);
        messageButton.setText("Message");
        messageButton.setBackgroundColor(Color.parseColor("#0088CC"));
        messageButton.setTextColor(Color.WHITE);
        messageButton.setPadding(15, 8, 15, 8);
        messageButton.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1
        ));
        
        messageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startChatWithContact(name, telegramId);
            }
        });
        
        Button callButton = new Button(this);
        callButton.setText("Call");
        callButton.setBackgroundColor(Color.parseColor("#4CAF50"));
        callButton.setTextColor(Color.WHITE);
        callButton.setPadding(15, 8, 15, 8);
        callButton.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1
        ));
        
        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ContactsActivity.this, "Calling " + phone, Toast.LENGTH_SHORT).show();
            }
        });
        
        buttonLayout.addView(messageButton);
        buttonLayout.addView(callButton);
        
        contactItem.addView(nameText);
        contactItem.addView(phoneText);
        contactItem.addView(telegramText);
        contactItem.addView(buttonLayout);
        
        contactsLayout.addView(contactItem);
    }
    
    private void addDemoContacts() {
        // Clear existing demo data and reinsert
        database.execSQL("DELETE FROM " + DatabaseHelper.TABLE_CONTACTS);
        
        // Insert fresh demo contacts using direct method
        insertDemoDataDirectly();
        
        Toast.makeText(this, "Demo contacts added!", Toast.LENGTH_SHORT).show();
        loadContacts();
    }
    
    private void insertDemoDataDirectly() {
        // Insert demo contacts directly
        database.execSQL("INSERT INTO " + DatabaseHelper.TABLE_CONTACTS + " (" 
            + DatabaseHelper.KEY_CONTACT_NAME + ", " + DatabaseHelper.KEY_PHONE_NUMBER + ", " + DatabaseHelper.KEY_TELEGRAM_USER_ID 
            + ") VALUES ('John Doe', '+1234567890', '123456789')");
            
        database.execSQL("INSERT INTO " + DatabaseHelper.TABLE_CONTACTS + " (" 
            + DatabaseHelper.KEY_CONTACT_NAME + ", " + DatabaseHelper.KEY_PHONE_NUMBER + ", " + DatabaseHelper.KEY_TELEGRAM_USER_ID 
            + ") VALUES ('Jane Smith', '+0987654321', '987654321')");
            
        database.execSQL("INSERT INTO " + DatabaseHelper.TABLE_CONTACTS + " (" 
            + DatabaseHelper.KEY_CONTACT_NAME + ", " + DatabaseHelper.KEY_PHONE_NUMBER + ", " + DatabaseHelper.KEY_TELEGRAM_USER_ID 
            + ") VALUES ('Mike Wilson', '+1122334455', '555666777')");
    }
    
    private void startChatWithContact(String contactName, String telegramId) {
        Toast.makeText(this, "Starting chat with " + contactName, Toast.LENGTH_SHORT).show();
        
        // In Phase 3, this will open ChatActivity with the specific contact
        // For now, just show a message and open regular chat
        Intent intent = new Intent(this, ChatActivity.class);
        intent.putExtra("contact_name", contactName);
        intent.putExtra("telegram_id", telegramId);
        startActivity(intent);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (database != null) {
            database.close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}