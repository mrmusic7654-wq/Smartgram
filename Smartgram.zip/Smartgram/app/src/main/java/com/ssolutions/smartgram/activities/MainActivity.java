package com.ssolutions.smartgram.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.ssolutions.smartgram.utils.SharedPrefs;
import com.ssolutions.smartgram.network.TelegramAPI;

public class MainActivity extends Activity {
    
    private TelegramAPI telegramAPI;
    private static final String TAG = "MainActivity";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            Log.d(TAG, "MainActivity started");
            
            // Check login state
            if (!SharedPrefs.isLoggedIn()) {
                Log.d(TAG, "User not logged in, redirecting to LoginActivity");
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
                return;
            }
            
            // Initialize SharedPrefs if not already
            if (SharedPrefs.getUserId() == null) {
                SharedPrefs.init(this);
            }
            
            // Initialize Telegram API
            telegramAPI = new TelegramAPI(this);
            
            createMainUI();
            
            // Test bot connection
            telegramAPI.getMe();
            
            Log.d(TAG, "MainActivity created successfully");
            
        } catch (Exception e) {
            Log.e(TAG, "Error in MainActivity onCreate: " + e.getMessage(), e);
            showErrorScreen("App Error: " + e.getMessage());
        }
    }
    
    private void createMainUI() {
        try {
            LinearLayout mainLayout = new LinearLayout(this);
            mainLayout.setOrientation(LinearLayout.VERTICAL);
            mainLayout.setBackgroundColor(Color.WHITE);
            mainLayout.setPadding(50, 100, 50, 50);
            
            // App Title
            TextView title = new TextView(this);
            title.setText("Smartgram");
            title.setTextSize(28);
            title.setTextColor(Color.parseColor("#0088CC"));
            title.setPadding(0, 0, 0, 20);
            
            // Status
            TextView status = new TextView(this);
            status.setText("✓ Connected to Telegram");
            status.setTextSize(14);
            status.setTextColor(Color.parseColor("#4CAF50"));
            status.setPadding(0, 0, 0, 30);
            
            // User Info
            TextView userInfo = new TextView(this);
            userInfo.setText("Bot Token: " + getMaskedToken(SharedPrefs.getBotToken()) + 
                            "\nPhone: " + SharedPrefs.getPhoneNumber());
            userInfo.setTextSize(12);
            userInfo.setTextColor(Color.GRAY);
            userInfo.setPadding(0, 0, 0, 40);
            
            // Features List
            TextView features = new TextView(this);
            features.setText("Phase 2 Features:\n\n" +
                            "✅ Real Telegram API\n" +
                            "✅ Bot Authentication\n" +
                            "✅ Message Sending\n" +
                            "✅ Contact Management\n" +
                            "✅ Local Database\n" +
                            "✅ Background Sync\n\n" +
                            "Coming in Phase 3:\n" +
                            "• Group Chats\n" +
                            "• File Sharing\n" +
                            "• Message Sync");
            features.setTextSize(14);
            features.setTextColor(Color.DKGRAY);
            features.setPadding(0, 0, 0, 50);
            
            // Button Layout
            LinearLayout buttonLayout = new LinearLayout(this);
            buttonLayout.setOrientation(LinearLayout.VERTICAL);
            
            // Demo Chat Button
            Button chatButton = createButton("Open Demo Chat", Color.parseColor("#0088CC"));
            chatButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Error opening chat: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            
            // Contacts Button
            Button contactsButton = createButton("Manage Contacts", Color.parseColor("#4CAF50"));
            contactsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Error opening contacts: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            
            // Settings Button
            Button settingsButton = createButton("Settings", Color.parseColor("#FF9800"));
            settingsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
                        startActivity(intent);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Error opening settings: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
            
            // Test Telegram Button
            Button testTelegramButton = createButton("Test Telegram API", Color.parseColor("#9C27B0"));
            testTelegramButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    testTelegramAPI();
                }
            });
            
            // Add buttons to layout
            buttonLayout.addView(chatButton);
            buttonLayout.addView(contactsButton);
            buttonLayout.addView(settingsButton);
            buttonLayout.addView(testTelegramButton);
            
            // Add all views to main layout
            mainLayout.addView(title);
            mainLayout.addView(status);
            mainLayout.addView(userInfo);
            mainLayout.addView(features);
            mainLayout.addView(buttonLayout);
            
            setContentView(mainLayout);
            
            Toast.makeText(this, "Phase 2: Telegram Integration Active!", Toast.LENGTH_LONG).show();
            
        } catch (Exception e) {
            Log.e(TAG, "Error creating UI: " + e.getMessage(), e);
            showErrorScreen("UI Error: " + e.getMessage());
        }
    }
    
    private Button createButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setBackgroundColor(color);
        button.setTextColor(Color.WHITE);
        button.setPadding(40, 20, 40, 20);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, 15);
        button.setLayoutParams(params);
        
        return button;
    }
    
    private String getMaskedToken(String token) {
        if (token == null || token.length() <= 10) return "Not set";
        return token.substring(0, 10) + "..." + token.substring(token.length() - 5);
    }
    
    private void testTelegramAPI() {
        try {
            Toast.makeText(this, "Testing Telegram API...", Toast.LENGTH_SHORT).show();
            
            String testChatId = "123456789";
            telegramAPI.sendMessage(testChatId, "Test message from Smartgram Phase 2!");
            
            Toast.makeText(this, "Check your Telegram bot for test message", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Telegram API Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    private void showErrorScreen(String errorMessage) {
        LinearLayout errorLayout = new LinearLayout(this);
        errorLayout.setOrientation(LinearLayout.VERTICAL);
        errorLayout.setBackgroundColor(Color.WHITE);
        errorLayout.setPadding(50, 100, 50, 50);
        
        TextView errorTitle = new TextView(this);
        errorTitle.setText("App Error");
        errorTitle.setTextSize(20);
        errorTitle.setTextColor(Color.RED);
        errorTitle.setPadding(0, 0, 0, 20);
        
        TextView errorText = new TextView(this);
        errorText.setText(errorMessage);
        errorText.setTextSize(14);
        errorText.setTextColor(Color.BLACK);
        errorText.setPadding(0, 0, 0, 30);
        
        Button restartButton = new Button(this);
        restartButton.setText("Restart App");
        restartButton.setBackgroundColor(Color.parseColor("#0088CC"));
        restartButton.setTextColor(Color.WHITE);
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }
        });
        
        errorLayout.addView(errorTitle);
        errorLayout.addView(errorText);
        errorLayout.addView(restartButton);
        
        setContentView(errorLayout);
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "MainActivity resumed");
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MainActivity destroyed");
    }
}