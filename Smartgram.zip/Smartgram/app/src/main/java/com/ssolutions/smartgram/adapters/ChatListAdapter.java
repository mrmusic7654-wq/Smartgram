package com.ssolutions.smartgram.adapters;

import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.TextView;
import android.widget.LinearLayout;
import com.ssolutions.smartgram.models.Chat;

// Simple adapter - we'll implement RecyclerView later when dependencies work
public class ChatListAdapter {
    // This is a placeholder for now
    // We'll implement the actual adapter when we have RecyclerView working
}