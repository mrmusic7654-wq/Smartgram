package com.ssolutions.smartgram.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Switch;
import com.ssolutions.smartgram.utils.SharedPrefs;

public class SettingsActivity extends Activity {
    
    private Switch autoDownloadSwitch;
    private Button logoutButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createSettingsUI();
    }
    
    private void createSettingsUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.WHITE);
        
        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(Color.parseColor("#0088CC"));
        header.setPadding(20, 20, 20, 20);
        
        TextView headerText = new TextView(this);
        headerText.setText("Settings");
        headerText.setTextSize(18);
        headerText.setTextColor(Color.WHITE);
        
        header.addView(headerText);
        
        // Settings container
        LinearLayout settingsLayout = new LinearLayout(this);
        settingsLayout.setOrientation(LinearLayout.VERTICAL);
        settingsLayout.setPadding(20, 20, 20, 20);
        
        // Account Section
        TextView accountSection = new TextView(this);
        accountSection.setText("ACCOUNT");
        accountSection.setTextSize(16);
        accountSection.setTextColor(Color.parseColor("#0088CC"));
        accountSection.setPadding(0, 0, 0, 10);
        
        // User Info
        LinearLayout userInfoLayout = new LinearLayout(this);
        userInfoLayout.setOrientation(LinearLayout.VERTICAL);
        userInfoLayout.setBackgroundColor(Color.parseColor("#F8F8F8"));
        userInfoLayout.setPadding(15, 15, 15, 15);
        
        TextView userName = new TextView(this);
        userName.setText("User: " + SharedPrefs.getUserName());
        userName.setTextSize(14);
        userName.setTextColor(Color.BLACK);
        
        TextView phoneNumber = new TextView(this);
        phoneNumber.setText("Phone: " + SharedPrefs.getPhoneNumber());
        phoneNumber.setTextSize(14);
        phoneNumber.setTextColor(Color.DKGRAY);
        
        TextView botToken = new TextView(this);
        String token = SharedPrefs.getBotToken();
        String maskedToken = token.length() > 10 ? 
            token.substring(0, 10) + "..." + token.substring(token.length() - 5) : "Not set";
        botToken.setText("Bot Token: " + maskedToken);
        botToken.setTextSize(12);
        botToken.setTextColor(Color.GRAY);
        
        userInfoLayout.addView(userName);
        userInfoLayout.addView(phoneNumber);
        userInfoLayout.addView(botToken);
        
        // Preferences Section
        TextView prefSection = new TextView(this);
        prefSection.setText("PREFERENCES");
        prefSection.setTextSize(16);
        prefSection.setTextColor(Color.parseColor("#0088CC"));
        prefSection.setPadding(0, 30, 0, 10);
        
        // Auto Download Switch
        LinearLayout autoDownloadLayout = new LinearLayout(this);
        autoDownloadLayout.setOrientation(LinearLayout.HORIZONTAL);
        autoDownloadLayout.setBackgroundColor(Color.parseColor("#F8F8F8"));
        autoDownloadLayout.setPadding(15, 15, 15, 15);
        
        TextView autoDownloadText = new TextView(this);
        autoDownloadText.setText("Auto-download media");
        autoDownloadText.setTextSize(14);
        autoDownloadText.setTextColor(Color.BLACK);
        autoDownloadText.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1
        ));
        
        autoDownloadSwitch = new Switch(this);
        autoDownloadSwitch.setChecked(SharedPrefs.getAutoDownload());
        autoDownloadSwitch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPrefs.setAutoDownload(autoDownloadSwitch.isChecked());
                Toast.makeText(SettingsActivity.this, 
                    "Auto-download " + (autoDownloadSwitch.isChecked() ? "enabled" : "disabled"), 
                    Toast.LENGTH_SHORT).show();
            }
        });
        
        autoDownloadLayout.addView(autoDownloadText);
        autoDownloadLayout.addView(autoDownloadSwitch);
        
        // App Info Section
        TextView infoSection = new TextView(this);
        infoSection.setText("APP INFORMATION");
        infoSection.setTextSize(16);
        infoSection.setTextColor(Color.parseColor("#0088CC"));
        infoSection.setPadding(0, 30, 0, 10);
        
        // App Info
        LinearLayout appInfoLayout = new LinearLayout(this);
        appInfoLayout.setOrientation(LinearLayout.VERTICAL);
        appInfoLayout.setBackgroundColor(Color.parseColor("#F8F8F8"));
        appInfoLayout.setPadding(15, 15, 15, 15);
        
        TextView versionInfo = new TextView(this);
        versionInfo.setText("Version: 1.0 (Phase 2)");
        versionInfo.setTextSize(14);
        versionInfo.setTextColor(Color.BLACK);
        
        TextView phaseInfo = new TextView(this);
        phaseInfo.setText("Status: Telegram Integration Active");
        phaseInfo.setTextSize(12);
        phaseInfo.setTextColor(Color.parseColor("#4CAF50"));
        
        TextView nextPhase = new TextView(this);
        nextPhase.setText("Next: Phase 3 - Groups & File Sharing");
        nextPhase.setTextSize(12);
        nextPhase.setTextColor(Color.BLUE);
        
        appInfoLayout.addView(versionInfo);
        appInfoLayout.addView(phaseInfo);
        appInfoLayout.addView(nextPhase);
        
        // Logout Button
        logoutButton = new Button(this);
        logoutButton.setText("Logout");
        logoutButton.setBackgroundColor(Color.parseColor("#FF5722"));
        logoutButton.setTextColor(Color.WHITE);
        logoutButton.setPadding(40, 20, 40, 20);
        logoutButton.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
        
        // Add all views to settings layout
        settingsLayout.addView(accountSection);
        settingsLayout.addView(userInfoLayout);
        settingsLayout.addView(prefSection);
        settingsLayout.addView(autoDownloadLayout);
        settingsLayout.addView(infoSection);
        settingsLayout.addView(appInfoLayout);
        settingsLayout.addView(logoutButton);
        
        // Add all views to main layout
        mainLayout.addView(header);
        mainLayout.addView(settingsLayout);
        
        setContentView(mainLayout);
    }
    
    private void logout() {
        SharedPrefs.clearAll();
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show();
        
        // Return to login screen
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}