package com.ssolutions.smartgram.activities;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.ssolutions.smartgram.utils.SharedPrefs;

public class LoginActivity extends Activity {
    
    private EditText botTokenInput, phoneNumberInput;
    private Button loginButton;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Check if already logged in
        if (SharedPrefs.isLoggedIn()) {
            startMainActivity();
            return;
        }
        
        createLoginUI();
    }
    
    private void createLoginUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.WHITE);
        mainLayout.setPadding(50, 100, 50, 50);
        
        // Title
        TextView title = new TextView(this);
        title.setText("Smartgram Setup");
        title.setTextSize(24);
        title.setTextColor(Color.parseColor("#0088CC"));
        title.setPadding(0, 0, 0, 30);
        
        // Instructions
        TextView instructions = new TextView(this);
        instructions.setText("To use Smartgram, you need:\n\n1. A Telegram Bot Token\n2. Your Phone Number");
        instructions.setTextSize(14);
        instructions.setTextColor(Color.DKGRAY);
        instructions.setPadding(0, 0, 0, 40);
        
        // Bot Token Input
        TextView botTokenLabel = new TextView(this);
        botTokenLabel.setText("Bot Token:");
        botTokenLabel.setTextSize(16);
        botTokenLabel.setTextColor(Color.BLACK);
        botTokenLabel.setPadding(0, 0, 0, 10);
        
        botTokenInput = new EditText(this);
        botTokenInput.setHint("123456789:ABCdefGHIjklMNOpqrSTUvwxYZ");
        botTokenInput.setBackgroundColor(Color.parseColor("#F5F5F5"));
        botTokenInput.setPadding(20, 15, 20, 15);
        botTokenInput.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        // Phone Number Input
        TextView phoneLabel = new TextView(this);
        phoneLabel.setText("Your Phone Number:");
        phoneLabel.setTextSize(16);
        phoneLabel.setTextColor(Color.BLACK);
        phoneLabel.setPadding(0, 20, 0, 10);
        
        phoneNumberInput = new EditText(this);
        phoneNumberInput.setHint("+1234567890");
        phoneNumberInput.setBackgroundColor(Color.parseColor("#F5F5F5"));
        phoneNumberInput.setPadding(20, 15, 20, 15);
        phoneNumberInput.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        // Login Button
        loginButton = new Button(this);
        loginButton.setText("Connect to Telegram");
        loginButton.setBackgroundColor(Color.parseColor("#0088CC"));
        loginButton.setTextColor(Color.WHITE);
        loginButton.setPadding(40, 20, 40, 20);
        loginButton.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });
        
        // Add all views
        mainLayout.addView(title);
        mainLayout.addView(instructions);
        mainLayout.addView(botTokenLabel);
        mainLayout.addView(botTokenInput);
        mainLayout.addView(phoneLabel);
        mainLayout.addView(phoneNumberInput);
        mainLayout.addView(loginButton);
        
        setContentView(mainLayout);
    }
    
    private void attemptLogin() {
        String botToken = botTokenInput.getText().toString().trim();
        String phoneNumber = phoneNumberInput.getText().toString().trim();
        
        if (botToken.isEmpty() || phoneNumber.isEmpty()) {
            Toast.makeText(this, "Please enter both bot token and phone number", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Save credentials
        SharedPrefs.setBotToken(botToken);
        SharedPrefs.setUserName("User");
        SharedPrefs.setLoggedIn(true);
        
        Toast.makeText(this, "Successfully connected to Telegram!", Toast.LENGTH_SHORT).show();
        startMainActivity();
    }
    
    private void startMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}