package com.ssolutions.smartgram.activities;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.ssolutions.smartgram.network.TelegramAPI;

public class ChatActivity extends Activity {
    
    private EditText messageInput;
    private ImageButton sendButton;
    private LinearLayout messagesLayout;
    private ScrollView scrollView;
    private TelegramAPI telegramAPI;
    private String currentChatId = "123456789"; // Demo chat ID
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Initialize Telegram API
        telegramAPI = new TelegramAPI(this);
        
        createChatUI();
    }
    
    private void createChatUI() {
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setBackgroundColor(Color.WHITE);
        
        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setBackgroundColor(Color.parseColor("#0088CC"));
        header.setPadding(20, 20, 20, 20);
        
        TextView headerText = new TextView(this);
        headerText.setText("Demo Chat (Telegram Connected)");
        headerText.setTextSize(16);
        headerText.setTextColor(Color.WHITE);
        headerText.setGravity(Gravity.CENTER_VERTICAL);
        
        header.addView(headerText);
        
        // Messages area with ScrollView
        scrollView = new ScrollView(this);
        messagesLayout = new LinearLayout(this);
        messagesLayout.setOrientation(LinearLayout.VERTICAL);
        messagesLayout.setPadding(20, 20, 20, 20);
        
        // Add sample messages showing Phase 2 features
        addMessage("Welcome to Smartgram Phase 2! 🚀", false, "10:00 AM");
        addMessage("This chat now has real Telegram API integration", false, "10:01 AM");
        addMessage("Your messages will be sent via Telegram bot", false, "10:02 AM");
        addMessage("Try sending a message to test the integration!", true, "10:03 AM");
        
        scrollView.addView(messagesLayout);
        
        // Input area
        LinearLayout inputLayout = new LinearLayout(this);
        inputLayout.setOrientation(LinearLayout.HORIZONTAL);
        inputLayout.setPadding(20, 10, 20, 20);
        inputLayout.setBackgroundColor(Color.parseColor("#F5F5F5"));
        
        messageInput = new EditText(this);
        messageInput.setHint("Type a message (will send via Telegram)...");
        messageInput.setBackgroundColor(Color.WHITE);
        messageInput.setPadding(20, 15, 20, 15);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(
            0, 
            LinearLayout.LayoutParams.WRAP_CONTENT, 
            1
        );
        inputParams.setMargins(0, 0, 10, 0);
        messageInput.setLayoutParams(inputParams);
        
        sendButton = new ImageButton(this);
        sendButton.setImageResource(android.R.drawable.ic_menu_send);
        sendButton.setBackgroundColor(Color.parseColor("#0088CC"));
        sendButton.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
        
        inputLayout.addView(messageInput);
        inputLayout.addView(sendButton);
        
        // Add all views to main layout
        mainLayout.addView(header);
        mainLayout.addView(scrollView, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1
        ));
        mainLayout.addView(inputLayout);
        
        setContentView(mainLayout);
        
        // Scroll to bottom
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }
    
    private void addMessage(String text, boolean isSent, String time) {
        LinearLayout messageLayout = new LinearLayout(this);
        messageLayout.setOrientation(LinearLayout.VERTICAL);
        
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        
        if (isSent) {
            layoutParams.gravity = Gravity.END;
            messageLayout.setBackgroundColor(Color.parseColor("#DCF8C6")); // Green bubble
        } else {
            layoutParams.gravity = Gravity.START;
            messageLayout.setBackgroundColor(Color.parseColor("#FFFFFF")); // White bubble
        }
        
        layoutParams.setMargins(10, 5, 10, 5);
        messageLayout.setPadding(15, 10, 15, 10);
        messageLayout.setLayoutParams(layoutParams);
        
        // Message text
        TextView messageText = new TextView(this);
        messageText.setText(text);
        messageText.setTextSize(16);
        messageText.setTextColor(Color.BLACK);
        
        // Time stamp
        TextView timeText = new TextView(this);
        timeText.setText(time + (isSent ? " ✓" : ""));
        timeText.setTextSize(10);
        timeText.setTextColor(Color.GRAY);
        timeText.setGravity(Gravity.END);
        
        messageLayout.addView(messageText);
        messageLayout.addView(timeText);
        
        messagesLayout.addView(messageLayout);
    }
    
    private void sendMessage() {
        String message = messageInput.getText().toString().trim();
        if (!message.isEmpty()) {
            // Add message to UI immediately
            addMessage(message, true, "Sending...");
            messageInput.setText("");
            
            // Send via Telegram API
            telegramAPI.sendMessage(currentChatId, message);
            
            // Update message status
            updateLastMessageStatus("Now ✓");
            
            scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            
            Toast.makeText(this, "Message sent via Telegram API!", Toast.LENGTH_SHORT).show();
        }
    }
    
    private void updateLastMessageStatus(String newStatus) {
        int lastIndex = messagesLayout.getChildCount() - 1;
        if (lastIndex >= 0) {
            View lastMessage = messagesLayout.getChildAt(lastIndex);
            if (lastMessage instanceof LinearLayout) {
                LinearLayout messageLayout = (LinearLayout) lastMessage;
                if (messageLayout.getChildCount() > 1) {
                    View timeView = messageLayout.getChildAt(1);
                    if (timeView instanceof TextView) {
                        ((TextView) timeView).setText(newStatus);
                    }
                }
            }
        }
    }
}