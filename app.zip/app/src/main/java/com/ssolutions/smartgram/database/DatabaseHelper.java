package com.ssolutions.smartgram.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "smartgram.db";
    private static final int DATABASE_VERSION = 2; // Updated for Phase 2
    
    // Table names
    public static final String TABLE_CHATS = "chats";
    public static final String TABLE_MESSAGES = "messages";
    public static final String TABLE_CONTACTS = "contacts";
    public static final String TABLE_USERS = "users";
    
    // Common column names
    public static final String KEY_ID = "id";
    public static final String KEY_CREATED_AT = "created_at";
    
    // Chats table columns
    public static final String KEY_CHAT_NAME = "chat_name";
    public static final String KEY_LAST_MESSAGE = "last_message";
    public static final String KEY_TIMESTAMP = "timestamp";
    public static final String KEY_IS_GROUP = "is_group";
    public static final String KEY_UNREAD_COUNT = "unread_count";
    public static final String KEY_TELEGRAM_CHAT_ID = "telegram_chat_id";
    
    // Messages table columns
    public static final String KEY_CHAT_ID = "chat_id";
    public static final String KEY_MESSAGE_TEXT = "message_text";
    public static final String KEY_SENDER_ID = "sender_id";
    public static final String KEY_MESSAGE_TYPE = "message_type";
    public static final String KEY_TELEGRAM_MESSAGE_ID = "telegram_message_id";
    public static final String KEY_IS_SENT = "is_sent";
    
    // Contacts table columns
    public static final String KEY_CONTACT_NAME = "contact_name";
    public static final String KEY_PHONE_NUMBER = "phone_number";
    public static final String KEY_TELEGRAM_USER_ID = "telegram_user_id";
    
    // Create statements
    private static final String CREATE_TABLE_CHATS = "CREATE TABLE " + TABLE_CHATS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_TELEGRAM_CHAT_ID + " TEXT UNIQUE,"
            + KEY_CHAT_NAME + " TEXT,"
            + KEY_LAST_MESSAGE + " TEXT,"
            + KEY_TIMESTAMP + " TEXT,"
            + KEY_IS_GROUP + " INTEGER DEFAULT 0,"
            + KEY_UNREAD_COUNT + " INTEGER DEFAULT 0,"
            + KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
            
    private static final String CREATE_TABLE_MESSAGES = "CREATE TABLE " + TABLE_MESSAGES + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_TELEGRAM_MESSAGE_ID + " TEXT,"
            + KEY_CHAT_ID + " TEXT,"
            + KEY_MESSAGE_TEXT + " TEXT,"
            + KEY_SENDER_ID + " TEXT,"
            + KEY_MESSAGE_TYPE + " INTEGER DEFAULT 1,"
            + KEY_IS_SENT + " INTEGER DEFAULT 0,"
            + KEY_TIMESTAMP + " TEXT,"
            + KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
    
    private static final String CREATE_TABLE_CONTACTS = "CREATE TABLE " + TABLE_CONTACTS + "("
            + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + KEY_CONTACT_NAME + " TEXT,"
            + KEY_PHONE_NUMBER + " TEXT,"
            + KEY_TELEGRAM_USER_ID + " TEXT UNIQUE,"
            + KEY_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP"
            + ")";
    
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_CHATS);
        db.execSQL(CREATE_TABLE_MESSAGES);
        db.execSQL(CREATE_TABLE_CONTACTS);
        
        // Insert demo data
        insertDemoData(db);
    }
    
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CHATS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONTACTS);
        onCreate(db);
    }
    
    public void insertDemoData(SQLiteDatabase db) {
        // Insert demo contacts
        db.execSQL("INSERT INTO " + TABLE_CONTACTS + " (" 
            + KEY_CONTACT_NAME + ", " + KEY_PHONE_NUMBER + ", " + KEY_TELEGRAM_USER_ID 
            + ") VALUES ('John Doe', '+1234567890', '123456789')");
            
        db.execSQL("INSERT INTO " + TABLE_CONTACTS + " (" 
            + KEY_CONTACT_NAME + ", " + KEY_PHONE_NUMBER + ", " + KEY_TELEGRAM_USER_ID 
            + ") VALUES ('Jane Smith', '+0987654321', '987654321')");
    }
}