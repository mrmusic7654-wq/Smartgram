package com.ssolutions.smartgram.models;

public class Message {
    private String id;
    private String senderId;
    private String text;
    private String timestamp;
    private boolean isSent; // true if sent by current user, false if received
    private int messageType; // 1=text, 2=image, 3=video, etc.
    private boolean isRead;
    
    // Constructors
    public Message() {}
    
    public Message(String id, String senderId, String text, String timestamp, boolean isSent) {
        this.id = id;
        this.senderId = senderId;
        this.text = text;
        this.timestamp = timestamp;
        this.isSent = isSent;
        this.messageType = 1; // Default to text
        this.isRead = true;
    }
    
    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getSenderId() { return senderId; }
    public void setSenderId(String senderId) { this.senderId = senderId; }
    
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    
    public boolean isSent() { return isSent; }
    public void setSent(boolean sent) { isSent = sent; }
    
    public int getMessageType() { return messageType; }
    public void setMessageType(int messageType) { this.messageType = messageType; }
    
    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }
}