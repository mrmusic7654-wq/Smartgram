package com.ssolutions.smartgram.network;

import android.content.Context;
import android.widget.Toast;
import com.ssolutions.smartgram.utils.SharedPrefs;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class TelegramAPI {
    private Context context;
    
    public TelegramAPI(Context context) {
        this.context = context;
    }
    
    public void sendMessage(String chatId, String text) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String botToken = SharedPrefs.getBotToken();
                    if (botToken.isEmpty()) {
                        showToast("Please set bot token first");
                        return;
                    }
                    
                    String urlString = "https://api.telegram.org/bot" + botToken + "/sendMessage";
                    String postData = "chat_id=" + chatId + "&text=" + text;
                    
                    URL url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.getOutputStream().write(postData.getBytes());
                    
                    int responseCode = connection.getResponseCode();
                    if (responseCode == 200) {
                        showToast("Message sent via Telegram!");
                    } else {
                        showToast("Failed to send message: " + responseCode);
                    }
                    
                    connection.disconnect();
                    
                } catch (Exception e) {
                    showToast("Error: " + e.getMessage());
                }
            }
        }).start();
    }
    
    public void getMe() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String botToken = SharedPrefs.getBotToken();
                    if (botToken.isEmpty()) return;
                    
                    String urlString = "https://api.telegram.org/bot" + botToken + "/getMe";
                    URL url = new URL(urlString);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    StringBuilder response = new StringBuilder();
                    
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    
                    reader.close();
                    connection.disconnect();
                    
                    // Parse bot info
                    JSONObject jsonResponse = new JSONObject(response.toString());
                    if (jsonResponse.getBoolean("ok")) {
                        JSONObject botInfo = jsonResponse.getJSONObject("result");
                        String botName = botInfo.getString("first_name");
                        showToast("Connected to bot: " + botName);
                    }
                    
                } catch (Exception e) {
                    showToast("Error connecting to bot");
                }
            }
        }).start();
    }
    
    private void showToast(final String message) {
        // Run on UI thread
        android.os.Handler mainHandler = new android.os.Handler(context.getMainLooper());
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}